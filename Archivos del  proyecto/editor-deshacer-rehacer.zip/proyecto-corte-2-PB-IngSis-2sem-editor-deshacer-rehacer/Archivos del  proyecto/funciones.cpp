#include "funciones.h"
#include "MyString.h"
#include "MyEditor.h"
#include <ctype.h>
#include <time.h>
#include <windows.h>
#include <conio.h>
#include <iomanip>
using namespace std;

const double MAX_ID = 9999999999.0;   // documento de hasta 10 digitos

//=============== TABLAS DE TIPOS Y PREMIOS ===============//
// Un solo lugar con los textos y los puntos: se acabaron los switch repetidos.
static const char TIPOS[5][60] = {
    "Publicacion en revista internacional indexada",
    "Publicacion en revista nacional",
    "Ponencia en congreso internacional",
    "Ponencia en congreso nacional",
    "Articulo en boletin o revista estudiantil"
};
static const int PUNTOS_BASE[5] = {10, 7, 5, 3, 1};

static const char PREMIOS[4][60] = {
    "Primer lugar o mejor ponencia internacional",
    "Segundo o tercer lugar en ponencia internacional",
    "Premio nacional o mencion especial",
    "Sin premio o reconocimiento"
};
static const int PUNTOS_ADIC[4] = {5, 3, 2, 0};

static const char COLORES[7][60] = {
    "Rojo", "Verde", "Amarillo", "Azul", "Magenta", "Cian", "Blanco"
};

//===== DEFINICIONES DE FUNCIONES ====//

void presentacion(void){
	
    //Espaciado del logo.
    for (int i = 0; i < 7; i++) {
        cout << endl;
    }

    //Matriz que almacena el logo para ser mostrado posteriormente.
    char logo[10][70] = {
        " ____   _   _  ____   _      ___    ____    ___   _____  _____ ",
        "|  _ \\ | | | || __ ) | |    |_ _|  / ___|  / _ \\ |  ___||_   _|",
        "| |_) || | | ||  _ \\ | |     | |   \\___ \\ | | | || |_     | |  ",
        "|  __/ | |_| || |_) || |___  | |    ___) || |_| ||  _|    | |  ",
        "|_|     \\___/ |____/ |_____||___|  |____/  \\___/ |_|      |_|  ",
        "                                           ",
        "                                           ",
        "                                           ",
        "                                           ",
        "                                           "
    };

    //Impresión del logo.
    int alineador = 15;
    for (int i = 0; i < 9; i++) {
        cout << setw(alineador) << "" << logo[i] << endl;
    }

    cout << endl << endl;
    Sleep(2000);
    system("cls");
    
    for (int i = 0; i < 7; i++) {
        cout << endl;
    }
    
    for (int i = 0; i < 10; i++) {
    	switch(i){
    		case 6: cout<<setw(alineador+44)<<"UNIVERSIDAD DE CARTAGENA\n"; break;
    		case 7: cout<<setw(alineador+42)<<"Facultad de Ingenieria"; break;
			case 9: cout<<setw(alineador+40)<<"CORTE 2 - PROYECTO"; break;
			default: cout << setw(alineador) << "" << logo[i] << endl;
		}
    }
    
    Sleep(2000);
    system("cls");
    Sleep(1800);
    
    for (int i = 0; i < 12; i++) {
        cout << endl;
    }

    
    int alineador_barra = alineador;
    //Barra de carga.
    char barra[18];
    barra[10]=' ';
    barra[11]=' ';
    barra[12]=' ';
    barra[16]='%';
    barra[17]='\0';
    
		cout << "\033[?25l";   // oculta el cursor mientras carga
		cout << setw(alineador_barra) << "";
        cout << "\x1b""7";
	    for(int porcentaje = 0; porcentaje <= 100; porcentaje++){
	        int carga = porcentaje / 10;
	        for(int i = 0; i < 10; i++){
	            if(i < carga){
	                barra[i] = '#';
	            }else{
	                barra[i] = '-';
	            }
	        }
	        barra[10] = '\0';
	
	        // '\0338' regresa al inicio de la linea y todo se sobrescribe en la misma fila
	        cout << "\0338" << setw(alineador_barra) << "[" << barra << "] "<< setw(3) << porcentaje << "%";
    	         
    	         if (porcentaje < 100){
    	         	cout<<"  Cargando...";
				 }else{
				 	cout<<"  Listo!     ";
				 }
    	         cout<< flush;
	
    	    Sleep(5);
    	}

    	cout << "\033[?25h" << endl;   // vuelve a mostrar el cursor
    	Sleep(400);
    	
}//presentacion


int cad_l(const char texto[]){
	int i = 0;
	while(texto[i] != '\0'){
		i++;
	}
	return i;
}//largo de cadena de caracteres

void cad_cpy(char destino[], const char origen[]){
	int i = 0;
	while (origen[i] != '\0'){
		destino[i] = origen[i];
		i++;
	}
	destino[i] = '\0';
}//copiar cadenas


void mostrar_error_en(const char mensaje[], const char error[]){
	int columna = cad_l(mensaje) + 1;
	cout << "\0338\033["<<columna<<"G";
	cout << "\033[J <ERROR, " << error << ">";
	getch();
	cout<<"\r\033[2K";
}


//==================  validar entrada =====================//
double leer(bool esNumero, const char mensaje[], double minimo, double maximo, char texto[]){
	int columna_entrada = cad_l(mensaje)+1;
	while (true)
	{
		cout << mensaje << "\x1b""7";
		bool vacio = false;
		bool largo = false;
		if (!esNumero){
			cin.getline(texto, (int)maximo+1);
			if(cin.fail()){
				largo = !cin.eof();
				cin.clear();
				cin.ignore(10000, '\n');
				vacio = !largo;
			}else if(cad_l(texto)>0){
				return 0;
			}else{
				vacio = true;
			}
		}else{
			double x;
			cin>>x;
			bool ok = !cin.fail() && cin.peek() == '\n' && x >= minimo && x <= maximo;
			cin.clear();
			cin.ignore(10000, '\n');
			if(ok){
				return x;
			}
		}
		
		if(largo){
			mostrar_error_en(mensaje, "Dato demasiado largo");
		}else if(vacio){
			mostrar_error_en(mensaje, "Dato Vacio");
		}else{
			mostrar_error_en(mensaje, "Dato invalido o fuera de rango");
		}
	}
}

int menu(void){
	int opc=0;
		system("cls");
		cout<<"==========================================="<<endl;
		cout<<"                 PUBLISOFT                 "<<endl;
		cout<<"==========================================="<<endl;
		cout<<"   1. Registro de autores                  "<<endl;
		cout<<"   2. Registro de publicaciones            "<<endl;
		cout<<"   3. Asignacion y actualizacion de puntos "<<endl;
		cout<<"   4. Reportes y Consultas                 "<<endl;
		cout<<"   5. Estadisticas                         "<<endl;
		cout<<"   6. Regresar al inicio                   "<<endl;
		cout<<"\n";
		
		opc = (int)leer(true, "      OPCION -->", 1, 6);   // antes (1, 5): la opcion 6 nunca pasaba
		
		return opc;
	
}

//=============== AUXILIARES NUEVAS (usan tu leer) ===============//

// Pide UNA letra entre primera y ultima (acepta minusculas) y repite si no es valida.
char leerLetra(const char mensaje[], char primera, char ultima){
    char op[10];
    while(true){
        leer(false, mensaje, 0, 9, op);
        if (cad_l(op) == 1){
    	    char l = toupper((unsigned char)op[0]);
    	    if(l >= primera && l <= ultima){
    	        return l;
    	    }	
		}
        
        mostrar_error_en(mensaje, "Opcion invalida");
    }
}

// Muestra un menu numerado desde un arreglo de textos y devuelve la posicion elegida (0, 1, 2...).
int elegirOpcion(const char encabezado[], const char opciones[][60], int cantidad){
    cout << encabezado << endl;
    for(int i = 0; i < cantidad; i++){
        cout << "   " << i + 1 << ". " << opciones[i] << endl;
    }
    return (int)leer(true, "   Opcion --> ", 1, cantidad) - 1;
}

static bool tieneArroba(const char t[]){
    for(int i = 0; t[i] != '\0'; i++){
        if(t[i] == '@'){
            return true;
        }
    }
    return false;
}

//=============== BUSQUEDAS / VALIDACIONES ===============//

int buscarAutor(long long id, const vector<autor> &autores){
    for(int i = 0; i < (int)autores.size(); i++){
        if(autores[i].idAutor == id){
            return i;
        }
    }
    return -1;
}

bool existeIdPublicacion(long long id, const vector<publicacion> &publicaciones){
    for(int i = 0; i < (int)publicaciones.size(); i++){
        if(publicaciones[i].idPubli == id){
            return true;
        }
    }
    return false;
}

//=============== REGISTRO DE AUTORES ===============//

void registrarAutores(vector<autor> &autores){
	
    int n = (int)leer(true, "Cuantos autores desea registrar: ", 1, 100);
    for(int i = 0; i < n; i++){
        autor nuevo{};
        cout << endl << "--- AUTOR #" << i + 1 << " ---" << endl;

        while(true){
            long long id = (long long)leer(true, " - ID (documento): ", 1, MAX_ID);
            if(buscarAutor(id, autores) == -1){
                nuevo.idAutor = id;
                break;
            }
            mostrar_error_en(" - ID (documento): ", "ID ya registrado");
        }

        leer(false, " - Nombre completo: ", 0, 49, nuevo.nom);

        while(true){
            leer(false, " - Correo: ", 0, 59, nuevo.email);
            if(tieneArroba(nuevo.email)){
                break;
            }
            mostrar_error_en(" - Correo: ", "Correo invalido (falta @)");
        }

        leer(false, " - Programa: ", 0, 59, nuevo.programa);
        autores.push_back(nuevo);
    }
    cout << endl << "Autores registrados en total: " << autores.size() << endl;
    cout << "Presione una tecla para volver al menu ";
    getch();
}

//=============== REGISTRO DE PUBLICACIONES ===============//

// Elige el tipo y deja listos el texto y los puntos base (con "=", no "+=": sirve tambien al actualizar)
void tipoPublicacion(publicacion &nueva){
    int op = elegirOpcion("Tipo de publicacion:", TIPOS, 5);
    cad_cpy(nueva.tipoP, TIPOS[op]);
    nueva.baseP = PUNTOS_BASE[op];
}

// Elige el premio y deja listos el texto ("Ninguno" si no hay) y los puntos adicionales
void premioPublicacion(publicacion &nueva){
    int op = elegirOpcion("Premio o reconocimiento:", PREMIOS, 4);
    if(op == 3){
        cad_cpy(nueva.premio, "Ninguno");
    }else{
        cad_cpy(nueva.premio, PREMIOS[op]);
    }
    nueva.adicP = PUNTOS_ADIC[op];
}

void mostrarPuntos(const publicacion &p){
    cout << "   Puntos base:        " << p.baseP << endl;
    cout << "   Puntos adicionales: " << p.adicP << endl;
    cout << "   Total de puntos:    " << p.baseP + p.adicP << endl;
}

void registrarPublicaciones(vector<publicacion> &publicaciones, vector<autor> &autores){
    if(autores.empty()){
        cout << "Debe registrar al menos un autor primero." << endl;
        cout << "Presione una tecla para volver al menu ";
        getch();
        return;
    }

    time_t ahora = time(0);
    int anioActual = localtime(&ahora)->tm_year + 1900;

    int n = (int)leer(true, "Cuantas publicaciones desea registrar: ", 1, 100);
    for(int i = 0; i < n; i++){
        publicacion nueva{};
        system("cls");
        cout << "--- PUBLICACION #" << i + 1 << " ---" << endl;

        // El autor debe existir. Se pide el ID y el nombre se copia solo.
        int pos;
        while(true){
            long long idA = (long long)leer(true, " - ID del autor: ", 1, MAX_ID);
            pos = buscarAutor(idA, autores);
            if(pos != -1){
                break;
            }
            mostrar_error_en(" - ID del autor: ", "Autor no registrado");
        }
        nueva.idAutor = autores[pos].idAutor;
        cad_cpy(nueva.autor, autores[pos].nom);
        cout << "   Autor: " << nueva.autor << endl;

        // El ID de la publicacion no se puede repetir.
        while(true){
            long long idP = (long long)leer(true, " - ID de la publicacion: ", 1, MAX_ID);
            if(!existeIdPublicacion(idP, publicaciones)){
                nueva.idPubli = idP;
                break;
            }
            mostrar_error_en(" - ID de la publicacion: ", "ID ya registrado");
        }

        leer(false, " - Titulo: ", 0, 99, nueva.titulo);
        nueva.anio = (int)leer(true, " - Anio de publicacion: ", 1900, anioActual);
        cout << endl;
        tipoPublicacion(nueva);
        cout << endl;
        premioPublicacion(nueva);

        cout << endl << "Puntos asignados:" << endl;
        mostrarPuntos(nueva);
        cout << endl;

        leer(false, " - Abstract: ", 0, 499, nueva.abstract);
        editarAbstract(nueva);

        publicaciones.push_back(nueva);

        system("cls");
        cout << "PUBLICACION REGISTRADA (" << i + 1 << " de " << n << ")" << endl;
        cout << "   Titulo: " << nueva.titulo << endl;
        cout << "   Autor:  " << nueva.autor << endl;
        mostrarPuntos(nueva);
        cout << endl << "Presione una tecla para continuar ";
        getch();
    }
}

//=============== EDITOR My WP ===============//

void editarAbstract(publicacion &nueva){
    int quiere = (int)leer(true, "Desea analizar o editar el abstract? (1=Si, 0=No): ", 0, 1);
    if(quiere == 0){
        return;
    }
    while(true){
        system("cls");
        cout << "=========== My WP (Word Processor) ===========" << endl;
        cout << "   1. Analizar texto" << endl;
        cout << "   2. Editar texto" << endl;
        cout << "   3. Editor tipo nano (^X para salir)" << endl;
        cout << "   4. Salir" << endl;
        int op = (int)leer(true, "   Opcion --> ", 1, 4);
        if(op == 1){
            analizarTexto(nueva.abstract);
        }else if(op == 2){
            editarTexto(nueva.abstract);
        }else if(op == 3){
            editorNano(nueva.abstract, sizeof(nueva.abstract));
        }else{
            return;
        }
    }
}

void analizarTexto(const char texto[]){
    while(true){
        system("cls");
        cout << "=============== Analizar texto ===============" << endl;
        cout << "Abstract: " << texto << endl << endl;
        cout << "   A. Mostrar cantidad total de caracteres" << endl;
        cout << "   B. Contar vocales" << endl;
        cout << "   C. Contar caracteres numericos" << endl;
        cout << "   D. Contar espacios en blanco" << endl;
        cout << "   E. Contar caracteres especiales" << endl;
        cout << "   F. Cantidad de palabras" << endl;
        cout << "   G. Salir" << endl;
        char op = leerLetra("   Opcion --> ", 'A', 'G');
        if(op == 'G'){
            return;
        }
        cout << endl;
        switch(op){
            case 'A': cout << "Total de caracteres: " << totalCaracteres(texto) << endl; break;
            case 'B': cout << "Vocales: " << contarVocales(texto) << endl; break;
            case 'C': cout << "Caracteres numericos: " << contarNumeros(texto) << endl; break;
            case 'D': cout << "Espacios en blanco: " << contarEspacios(texto) << endl; break;
            case 'E': cout << "Caracteres especiales: " << contarEspeciales(texto) << endl; break;
            case 'F': cout << "Palabras: " << contarPalabras(texto) << endl; break;
        }
        cout << endl << "Presione una tecla para continuar ";
        getch();
    }
}

void editarTexto(char texto[]){
    while(true){
        system("cls");
        cout << "================ Editar texto ================" << endl;
        cout << "Abstract: " << texto << endl << endl;
        cout << "   A. Convertir todo el texto a mayusculas" << endl;
        cout << "   B. Convertir todo el texto a minusculas" << endl;
        cout << "   C. Detectar tipo de oracion" << endl;
        cout << "   D. Primera letra de cada palabra en mayuscula" << endl;
        cout << "   E. Asignar color" << endl;
        cout << "   F. Salir" << endl;
        char op = leerLetra("   Opcion --> ", 'A', 'F');
        if(op == 'F'){
            return;
        }
        cout << endl;
        switch(op){
            case 'A':
                aMayusculas(texto);
                cout << "Listo: " << texto << endl;
                break;
            case 'B':
                aMinusculas(texto);
                cout << "Listo: " << texto << endl;
                break;
            case 'C': {
                int decl, interr, excl;
                tipoOracion(texto, decl, interr, excl);
                cout << "Oraciones declarativas:   " << decl << endl;
                cout << "Oraciones interrogativas: " << interr << endl;
                cout << "Oraciones exclamativas:   " << excl << endl;
                break;
            }
            case 'D':
                primeraMayuscula(texto);
                cout << "Listo: " << texto << endl;
                break;
            case 'E': {
                int color = elegirOpcion("Color del texto:", COLORES, 7) + 1;
                cout << endl;
                asignarColor(texto, color);
                break;
            }
        }
        cout << endl << "Presione una tecla para continuar ";
        getch();
    }
}

//=============== PENDIENTES ===============//

void actualizarDatos(vector<autor> &autores, vector<publicacion> &publicaciones){
    cout << "En construccion..." << endl;
    getch();
}

void reportes(const vector<autor> &autores, const vector<publicacion> &publicaciones){
    cout << "En construccion..." << endl;
    getch();
}

void estadisticas(const vector<autor> &autores, const vector<publicacion> &publicaciones){
    cout << "En construccion..." << endl;
    getch();
}
